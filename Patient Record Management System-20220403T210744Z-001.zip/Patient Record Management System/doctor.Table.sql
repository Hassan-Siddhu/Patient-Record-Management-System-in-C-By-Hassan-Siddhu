﻿CREATE TABLE [dbo].[DoctorTbl]
(
	[Docid] INT NOT NULL PRIMARY KEY, 
    [DocName] NCHAR(10) NULL, 
    [DocExp] NCHAR(10) NULL, 
    [DocPass] NCHAR(10) NULL
)
