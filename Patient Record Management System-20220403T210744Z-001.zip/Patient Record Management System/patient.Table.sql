﻿CREATE TABLE [dbo].[PatientTbl]
(
	[Patnid] INT NOT NULL PRIMARY KEY, 
    [PatnName] NCHAR(10) NULL, 
    [PatnAddress] NCHAR(10) NULL, 
    [PatnAge] INT NULL, 
    [PatnPhone] VARCHAR(MAX) NULL, 
    [PatnDisease] NCHAR(10) NULL, 
    [Genderbox] NCHAR(10) NULL, 
    [Bloodbox] NCHAR(10) NULL
)
