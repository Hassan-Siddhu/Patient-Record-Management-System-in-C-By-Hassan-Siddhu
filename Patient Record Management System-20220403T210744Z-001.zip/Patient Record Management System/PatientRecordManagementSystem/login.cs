﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
namespace PatientRecordManagementSystem
{
    public partial class login : Form
    {

        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-R41HJA1\SQLEXPRESS;Initial Catalog=patientrecordsystem;Integrated Security=True;Pooling=False");


        [DllImport("Gdi32.dll")]


        private static extern IntPtr CreateRoundRectRgn
            (
            int nLeftRect,
            int nTopRect,
            int RightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse

            );


        public login()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 0, 0));

        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            if (RespName.Text == "" || RespPass.Text == "")
                MessageBox.Show("Enter a UserName And Password");
            else
            {
                Con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from ReceptionistTbl where RespName='" + RespName.Text + "' and RespPass='" + RespPass.Text + "'", Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);


                if (dt.Rows[0][0].ToString() == "1")
                {
                    home H = new home();
                    H.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Wrong UserName or Password");
                }
                Con.Close();
            }
        }

        private void clearbtn_Click(object sender, EventArgs e)
        {
            RespName.Text = "";
            RespPass.Text = "";
        }

    }
}
