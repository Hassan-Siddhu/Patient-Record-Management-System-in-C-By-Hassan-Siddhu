﻿
namespace PatientRecordManagementSystem
{
    partial class patient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearbtn = new System.Windows.Forms.Label();
            this.Ptnshowdata = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ptntbtn = new System.Windows.Forms.PictureBox();
            this.PatnDisease = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Bloodbox = new System.Windows.Forms.ComboBox();
            this.Genderbox = new System.Windows.Forms.ComboBox();
            this.PatnPhone = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.PatnAge = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.PatnAddress = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.PatnName = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Patnid = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ptnthomebtn = new System.Windows.Forms.PictureBox();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.updatebtn = new System.Windows.Forms.Button();
            this.Addbtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptnshowdata)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptntbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptnthomebtn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.pngfind_com_golden_line_borders_png_825953;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.clearbtn);
            this.panel1.Controls.Add(this.Ptnshowdata);
            this.panel1.Controls.Add(this.ptntbtn);
            this.panel1.Controls.Add(this.PatnDisease);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.Bloodbox);
            this.panel1.Controls.Add(this.Genderbox);
            this.panel1.Controls.Add(this.PatnPhone);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.PatnAge);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.PatnAddress);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.PatnName);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.Patnid);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.ptnthomebtn);
            this.panel1.Controls.Add(this.Deletebtn);
            this.panel1.Controls.Add(this.updatebtn);
            this.panel1.Controls.Add(this.Addbtn);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(993, 547);
            this.panel1.TabIndex = 1;
            // 
            // clearbtn
            // 
            this.clearbtn.AutoSize = true;
            this.clearbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearbtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.clearbtn.Location = new System.Drawing.Point(184, 418);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.Size = new System.Drawing.Size(46, 19);
            this.clearbtn.TabIndex = 52;
            this.clearbtn.Text = "Clear";
            this.clearbtn.Click += new System.EventHandler(this.clearbtn_Click);
            // 
            // Ptnshowdata
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.Ptnshowdata.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.Ptnshowdata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Ptnshowdata.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Ptnshowdata.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Ptnshowdata.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Ptnshowdata.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Ptnshowdata.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.Ptnshowdata.ColumnHeadersHeight = 30;
            this.Ptnshowdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Ptnshowdata.DefaultCellStyle = dataGridViewCellStyle6;
            this.Ptnshowdata.EnableHeadersVisualStyles = false;
            this.Ptnshowdata.GridColor = System.Drawing.Color.White;
            this.Ptnshowdata.Location = new System.Drawing.Point(262, 130);
            this.Ptnshowdata.Name = "Ptnshowdata";
            this.Ptnshowdata.RowHeadersVisible = false;
            this.Ptnshowdata.RowTemplate.Height = 30;
            this.Ptnshowdata.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Ptnshowdata.Size = new System.Drawing.Size(697, 307);
            this.Ptnshowdata.TabIndex = 51;
            this.Ptnshowdata.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Ptnshowdata.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Ptnshowdata.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Ptnshowdata.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Ptnshowdata.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Ptnshowdata.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Ptnshowdata.ThemeStyle.GridColor = System.Drawing.Color.White;
            this.Ptnshowdata.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Ptnshowdata.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.Ptnshowdata.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ptnshowdata.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Ptnshowdata.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.Ptnshowdata.ThemeStyle.HeaderStyle.Height = 30;
            this.Ptnshowdata.ThemeStyle.ReadOnly = false;
            this.Ptnshowdata.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Ptnshowdata.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Ptnshowdata.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ptnshowdata.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Ptnshowdata.ThemeStyle.RowsStyle.Height = 30;
            this.Ptnshowdata.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Ptnshowdata.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Ptnshowdata.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Ptnshowdata_CellContentClick);
            // 
            // ptntbtn
            // 
            this.ptntbtn.BackColor = System.Drawing.Color.Transparent;
            this.ptntbtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.Patient;
            this.ptntbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptntbtn.Location = new System.Drawing.Point(367, 60);
            this.ptntbtn.Name = "ptntbtn";
            this.ptntbtn.Size = new System.Drawing.Size(72, 64);
            this.ptntbtn.TabIndex = 36;
            this.ptntbtn.TabStop = false;
            // 
            // PatnDisease
            // 
            this.PatnDisease.BorderColorFocused = System.Drawing.Color.Transparent;
            this.PatnDisease.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.PatnDisease.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.PatnDisease.BorderThickness = 3;
            this.PatnDisease.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatnDisease.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatnDisease.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.PatnDisease.isPassword = false;
            this.PatnDisease.Location = new System.Drawing.Point(46, 331);
            this.PatnDisease.Margin = new System.Windows.Forms.Padding(6);
            this.PatnDisease.Name = "PatnDisease";
            this.PatnDisease.Size = new System.Drawing.Size(173, 30);
            this.PatnDisease.TabIndex = 35;
            this.PatnDisease.TabStop = false;
            this.PatnDisease.Text = "Major Disease";
            this.PatnDisease.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel7.Location = new System.Drawing.Point(46, 366);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(173, 1);
            this.panel7.TabIndex = 34;
            // 
            // Bloodbox
            // 
            this.Bloodbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Bloodbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bloodbox.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Bloodbox.FormattingEnabled = true;
            this.Bloodbox.Items.AddRange(new object[] {
            "O+",
            "O-",
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-"});
            this.Bloodbox.Location = new System.Drawing.Point(46, 415);
            this.Bloodbox.Name = "Bloodbox";
            this.Bloodbox.Size = new System.Drawing.Size(121, 27);
            this.Bloodbox.TabIndex = 33;
            this.Bloodbox.Text = "Blood Group";
            // 
            // Genderbox
            // 
            this.Genderbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Genderbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderbox.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Genderbox.FormattingEnabled = true;
            this.Genderbox.Items.AddRange(new object[] {
            "Male ",
            "Female"});
            this.Genderbox.Location = new System.Drawing.Point(46, 373);
            this.Genderbox.Name = "Genderbox";
            this.Genderbox.Size = new System.Drawing.Size(121, 27);
            this.Genderbox.TabIndex = 32;
            this.Genderbox.Text = "Gender";
            // 
            // PatnPhone
            // 
            this.PatnPhone.BorderColorFocused = System.Drawing.Color.Transparent;
            this.PatnPhone.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.PatnPhone.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.PatnPhone.BorderThickness = 3;
            this.PatnPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatnPhone.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatnPhone.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.PatnPhone.isPassword = false;
            this.PatnPhone.Location = new System.Drawing.Point(46, 288);
            this.PatnPhone.Margin = new System.Windows.Forms.Padding(6);
            this.PatnPhone.Name = "PatnPhone";
            this.PatnPhone.Size = new System.Drawing.Size(173, 30);
            this.PatnPhone.TabIndex = 31;
            this.PatnPhone.TabStop = false;
            this.PatnPhone.Text = "Patient Phone";
            this.PatnPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel6.Location = new System.Drawing.Point(46, 323);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(173, 1);
            this.panel6.TabIndex = 30;
            // 
            // PatnAge
            // 
            this.PatnAge.BorderColorFocused = System.Drawing.Color.Transparent;
            this.PatnAge.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.PatnAge.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.PatnAge.BorderThickness = 3;
            this.PatnAge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatnAge.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatnAge.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.PatnAge.isPassword = false;
            this.PatnAge.Location = new System.Drawing.Point(46, 243);
            this.PatnAge.Margin = new System.Windows.Forms.Padding(6);
            this.PatnAge.Name = "PatnAge";
            this.PatnAge.Size = new System.Drawing.Size(173, 30);
            this.PatnAge.TabIndex = 29;
            this.PatnAge.TabStop = false;
            this.PatnAge.Text = "Patient Age";
            this.PatnAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel5.Location = new System.Drawing.Point(46, 278);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(173, 1);
            this.panel5.TabIndex = 28;
            // 
            // PatnAddress
            // 
            this.PatnAddress.BorderColorFocused = System.Drawing.Color.Transparent;
            this.PatnAddress.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.PatnAddress.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.PatnAddress.BorderThickness = 3;
            this.PatnAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatnAddress.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatnAddress.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.PatnAddress.isPassword = false;
            this.PatnAddress.Location = new System.Drawing.Point(46, 197);
            this.PatnAddress.Margin = new System.Windows.Forms.Padding(6);
            this.PatnAddress.Name = "PatnAddress";
            this.PatnAddress.Size = new System.Drawing.Size(173, 30);
            this.PatnAddress.TabIndex = 27;
            this.PatnAddress.TabStop = false;
            this.PatnAddress.Text = "Patient Address";
            this.PatnAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel4.Location = new System.Drawing.Point(46, 232);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(173, 1);
            this.panel4.TabIndex = 26;
            // 
            // PatnName
            // 
            this.PatnName.BorderColorFocused = System.Drawing.Color.Transparent;
            this.PatnName.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.PatnName.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.PatnName.BorderThickness = 3;
            this.PatnName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatnName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatnName.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.PatnName.isPassword = false;
            this.PatnName.Location = new System.Drawing.Point(46, 155);
            this.PatnName.Margin = new System.Windows.Forms.Padding(6);
            this.PatnName.Name = "PatnName";
            this.PatnName.Size = new System.Drawing.Size(173, 30);
            this.PatnName.TabIndex = 25;
            this.PatnName.TabStop = false;
            this.PatnName.Text = "Patient Name";
            this.PatnName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel2.Location = new System.Drawing.Point(46, 190);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(173, 1);
            this.panel2.TabIndex = 24;
            // 
            // Patnid
            // 
            this.Patnid.BorderColorFocused = System.Drawing.Color.Transparent;
            this.Patnid.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Patnid.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.Patnid.BorderThickness = 3;
            this.Patnid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Patnid.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Patnid.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Patnid.isPassword = false;
            this.Patnid.Location = new System.Drawing.Point(46, 108);
            this.Patnid.Margin = new System.Windows.Forms.Padding(6);
            this.Patnid.Name = "Patnid";
            this.Patnid.Size = new System.Drawing.Size(173, 30);
            this.Patnid.TabIndex = 23;
            this.Patnid.TabStop = false;
            this.Patnid.Text = "Patient ID";
            this.Patnid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel3.Location = new System.Drawing.Point(46, 143);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(173, 1);
            this.panel3.TabIndex = 22;
            // 
            // ptnthomebtn
            // 
            this.ptnthomebtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.home_golden;
            this.ptnthomebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptnthomebtn.Location = new System.Drawing.Point(565, 454);
            this.ptnthomebtn.Name = "ptnthomebtn";
            this.ptnthomebtn.Size = new System.Drawing.Size(82, 72);
            this.ptnthomebtn.TabIndex = 0;
            this.ptnthomebtn.TabStop = false;
            this.ptnthomebtn.Click += new System.EventHandler(this.ptnthomebtn_Click);
            // 
            // Deletebtn
            // 
            this.Deletebtn.FlatAppearance.BorderSize = 2;
            this.Deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Deletebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Deletebtn.Location = new System.Drawing.Point(163, 461);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(67, 37);
            this.Deletebtn.TabIndex = 20;
            this.Deletebtn.TabStop = false;
            this.Deletebtn.Text = "Delete";
            this.Deletebtn.UseVisualStyleBackColor = true;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.FlatAppearance.BorderSize = 2;
            this.updatebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updatebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.updatebtn.Location = new System.Drawing.Point(88, 461);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(69, 37);
            this.updatebtn.TabIndex = 19;
            this.updatebtn.TabStop = false;
            this.updatebtn.Text = "Update";
            this.updatebtn.UseVisualStyleBackColor = true;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.FlatAppearance.BorderSize = 2;
            this.Addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Addbtn.Location = new System.Drawing.Point(33, 461);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(49, 37);
            this.Addbtn.TabIndex = 18;
            this.Addbtn.TabStop = false;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = true;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Goldenrod;
            this.label2.Location = new System.Drawing.Point(244, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(515, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "Patient Record Management System";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(445, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "Patient";
            // 
            // patient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(996, 550);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "patient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "patient";
            this.Load += new System.EventHandler(this.patient_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptnshowdata)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptntbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptnthomebtn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox ptnthomebtn;
        private System.Windows.Forms.Button Deletebtn;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuMetroTextbox PatnDisease;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.ComboBox Bloodbox;
        private System.Windows.Forms.ComboBox Genderbox;
        private Bunifu.Framework.UI.BunifuMetroTextbox PatnPhone;
        private System.Windows.Forms.Panel panel6;
        private Bunifu.Framework.UI.BunifuMetroTextbox PatnAge;
        private System.Windows.Forms.Panel panel5;
        private Bunifu.Framework.UI.BunifuMetroTextbox PatnAddress;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.Framework.UI.BunifuMetroTextbox PatnName;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuMetroTextbox Patnid;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox ptntbtn;
        private Guna.UI2.WinForms.Guna2DataGridView Ptnshowdata;
        private System.Windows.Forms.Label clearbtn;
    }
}