﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace PatientRecordManagementSystem
{
    public partial class home : Form
    {
        [DllImport("Gdi32.dll")]

        private static extern IntPtr CreateRoundRectRgn
            (
            int nLeftRect,
            int nTopRect,
            int RightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse

            );

        public home()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 0, 0));
        }

        private void home_Load(object sender, EventArgs e)
        {

        }

        private void dctrbtn_Click(object sender, EventArgs e)
        {
            Doctor se_form = new Doctor();
            se_form.Show();
            this.Hide();
        }

        private void ptntbtn_Click(object sender, EventArgs e)
        {
            patient se_form = new patient();
            se_form.Show();
            this.Hide();
        }

        private void Diagnosisbtn_Click(object sender, EventArgs e)
        {
            Diagnosis se_form = new Diagnosis();
            se_form.Show();
            this.Hide();
        }

        private void Logoutbtn_Click(object sender, EventArgs e)
        {
            login se_form = new login();
            se_form.Show();
            this.Hide();
        }

        private void Receptionistbtn_Click(object sender, EventArgs e)
        {
            Receptionist se_form = new Receptionist();
            se_form.Show();
            this.Hide();
        }

        private void Exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
