﻿
namespace PatientRecordManagementSystem
{
    partial class Diagnosis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearbtn = new System.Windows.Forms.Label();
            this.diagsumry = new System.Windows.Forms.Panel();
            this.medicinelbl = new System.Windows.Forms.Label();
            this.diaglbl = new System.Windows.Forms.Label();
            this.symptmlbl = new System.Windows.Forms.Label();
            this.patnnamelbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.diagshowdata = new Guna.UI2.WinForms.Guna2DataGridView();
            this.medicinebox = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.patnidbox = new System.Windows.Forms.ComboBox();
            this.Diagbox = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Symptoms = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.PatnName1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Diagid = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.Updatebtn = new System.Windows.Forms.Button();
            this.Addbtn = new System.Windows.Forms.Button();
            this.homebtn = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.diagsumry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.diagshowdata)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.homebtn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.pngfind_com_golden_line_borders_png_825953;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.clearbtn);
            this.panel1.Controls.Add(this.diagsumry);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.diagshowdata);
            this.panel1.Controls.Add(this.medicinebox);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.patnidbox);
            this.panel1.Controls.Add(this.Diagbox);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.Symptoms);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.PatnName1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.Diagid);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.Deletebtn);
            this.panel1.Controls.Add(this.Updatebtn);
            this.panel1.Controls.Add(this.Addbtn);
            this.panel1.Controls.Add(this.homebtn);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(999, 576);
            this.panel1.TabIndex = 1;
            // 
            // clearbtn
            // 
            this.clearbtn.AutoSize = true;
            this.clearbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearbtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.clearbtn.Location = new System.Drawing.Point(322, 248);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.Size = new System.Drawing.Size(46, 19);
            this.clearbtn.TabIndex = 56;
            this.clearbtn.Text = "Clear";
            this.clearbtn.Click += new System.EventHandler(this.clearbtn_Click);
            // 
            // diagsumry
            // 
            this.diagsumry.Controls.Add(this.medicinelbl);
            this.diagsumry.Controls.Add(this.diaglbl);
            this.diagsumry.Controls.Add(this.symptmlbl);
            this.diagsumry.Controls.Add(this.patnnamelbl);
            this.diagsumry.Controls.Add(this.label4);
            this.diagsumry.Location = new System.Drawing.Point(451, 112);
            this.diagsumry.Name = "diagsumry";
            this.diagsumry.Size = new System.Drawing.Size(516, 246);
            this.diagsumry.TabIndex = 55;
            // 
            // medicinelbl
            // 
            this.medicinelbl.AutoSize = true;
            this.medicinelbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medicinelbl.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.medicinelbl.Location = new System.Drawing.Point(288, 158);
            this.medicinelbl.Name = "medicinelbl";
            this.medicinelbl.Size = new System.Drawing.Size(91, 24);
            this.medicinelbl.TabIndex = 6;
            this.medicinelbl.Text = "Medicine";
            // 
            // diaglbl
            // 
            this.diaglbl.AutoSize = true;
            this.diaglbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diaglbl.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.diaglbl.Location = new System.Drawing.Point(288, 65);
            this.diaglbl.Name = "diaglbl";
            this.diaglbl.Size = new System.Drawing.Size(95, 24);
            this.diaglbl.TabIndex = 5;
            this.diaglbl.Text = "Diagnosis";
            // 
            // symptmlbl
            // 
            this.symptmlbl.AutoSize = true;
            this.symptmlbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.symptmlbl.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.symptmlbl.Location = new System.Drawing.Point(11, 158);
            this.symptmlbl.Name = "symptmlbl";
            this.symptmlbl.Size = new System.Drawing.Size(103, 24);
            this.symptmlbl.TabIndex = 4;
            this.symptmlbl.Text = "Symptoms";
            // 
            // patnnamelbl
            // 
            this.patnnamelbl.AutoSize = true;
            this.patnnamelbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patnnamelbl.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.patnnamelbl.Location = new System.Drawing.Point(10, 65);
            this.patnnamelbl.Name = "patnnamelbl";
            this.patnnamelbl.Size = new System.Drawing.Size(133, 24);
            this.patnnamelbl.TabIndex = 3;
            this.patnnamelbl.Text = "Patient Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label4.Location = new System.Drawing.Point(187, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(215, 26);
            this.label4.TabIndex = 2;
            this.label4.Text = "Diagnosis Summary";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label3.Location = new System.Drawing.Point(393, 361);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(240, 42);
            this.label3.TabIndex = 54;
            this.label3.Text = "Diagnosis List";
            // 
            // diagshowdata
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.diagshowdata.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.diagshowdata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.diagshowdata.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.diagshowdata.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.diagshowdata.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.diagshowdata.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.diagshowdata.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.diagshowdata.ColumnHeadersHeight = 30;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.diagshowdata.DefaultCellStyle = dataGridViewCellStyle3;
            this.diagshowdata.EnableHeadersVisualStyles = false;
            this.diagshowdata.GridColor = System.Drawing.Color.Maroon;
            this.diagshowdata.Location = new System.Drawing.Point(30, 406);
            this.diagshowdata.Name = "diagshowdata";
            this.diagshowdata.RowHeadersVisible = false;
            this.diagshowdata.RowTemplate.Height = 30;
            this.diagshowdata.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.diagshowdata.Size = new System.Drawing.Size(937, 147);
            this.diagshowdata.TabIndex = 53;
            this.diagshowdata.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.diagshowdata.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diagshowdata.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.diagshowdata.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.diagshowdata.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.diagshowdata.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.diagshowdata.ThemeStyle.GridColor = System.Drawing.Color.Maroon;
            this.diagshowdata.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.diagshowdata.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.diagshowdata.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diagshowdata.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.diagshowdata.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.diagshowdata.ThemeStyle.HeaderStyle.Height = 30;
            this.diagshowdata.ThemeStyle.ReadOnly = false;
            this.diagshowdata.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.diagshowdata.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.diagshowdata.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diagshowdata.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.diagshowdata.ThemeStyle.RowsStyle.Height = 30;
            this.diagshowdata.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.diagshowdata.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.diagshowdata.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.diagshowdata_CellContentClick);
            // 
            // medicinebox
            // 
            this.medicinebox.BorderColorFocused = System.Drawing.Color.Transparent;
            this.medicinebox.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.medicinebox.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.medicinebox.BorderThickness = 3;
            this.medicinebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.medicinebox.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medicinebox.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.medicinebox.isPassword = false;
            this.medicinebox.Location = new System.Drawing.Point(242, 185);
            this.medicinebox.Margin = new System.Windows.Forms.Padding(6);
            this.medicinebox.Name = "medicinebox";
            this.medicinebox.Size = new System.Drawing.Size(173, 30);
            this.medicinebox.TabIndex = 52;
            this.medicinebox.TabStop = false;
            this.medicinebox.Text = "Medicine";
            this.medicinebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel7.Location = new System.Drawing.Point(242, 220);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(173, 1);
            this.panel7.TabIndex = 51;
            // 
            // patnidbox
            // 
            this.patnidbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.patnidbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patnidbox.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.patnidbox.FormattingEnabled = true;
            this.patnidbox.Items.AddRange(new object[] {
            "Male ",
            "Female"});
            this.patnidbox.Location = new System.Drawing.Point(44, 145);
            this.patnidbox.Name = "patnidbox";
            this.patnidbox.Size = new System.Drawing.Size(121, 27);
            this.patnidbox.TabIndex = 49;
            this.patnidbox.Text = "Patientid";
            this.patnidbox.SelectionChangeCommitted += new System.EventHandler(this.patnidbox_SelectionChangeCommitted);
            // 
            // Diagbox
            // 
            this.Diagbox.BorderColorFocused = System.Drawing.Color.Transparent;
            this.Diagbox.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Diagbox.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.Diagbox.BorderThickness = 3;
            this.Diagbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Diagbox.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Diagbox.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Diagbox.isPassword = false;
            this.Diagbox.Location = new System.Drawing.Point(242, 142);
            this.Diagbox.Margin = new System.Windows.Forms.Padding(6);
            this.Diagbox.Name = "Diagbox";
            this.Diagbox.Size = new System.Drawing.Size(173, 30);
            this.Diagbox.TabIndex = 48;
            this.Diagbox.TabStop = false;
            this.Diagbox.Text = "Diagnosis";
            this.Diagbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel6.Location = new System.Drawing.Point(242, 177);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(173, 1);
            this.panel6.TabIndex = 47;
            // 
            // Symptoms
            // 
            this.Symptoms.BorderColorFocused = System.Drawing.Color.Transparent;
            this.Symptoms.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Symptoms.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.Symptoms.BorderThickness = 3;
            this.Symptoms.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Symptoms.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Symptoms.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Symptoms.isPassword = false;
            this.Symptoms.Location = new System.Drawing.Point(242, 97);
            this.Symptoms.Margin = new System.Windows.Forms.Padding(6);
            this.Symptoms.Name = "Symptoms";
            this.Symptoms.Size = new System.Drawing.Size(173, 30);
            this.Symptoms.TabIndex = 46;
            this.Symptoms.TabStop = false;
            this.Symptoms.Text = "Symptoms";
            this.Symptoms.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel5.Location = new System.Drawing.Point(242, 132);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(173, 1);
            this.panel5.TabIndex = 45;
            // 
            // PatnName1
            // 
            this.PatnName1.BorderColorFocused = System.Drawing.Color.Transparent;
            this.PatnName1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.PatnName1.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.PatnName1.BorderThickness = 3;
            this.PatnName1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatnName1.Enabled = false;
            this.PatnName1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatnName1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.PatnName1.isPassword = false;
            this.PatnName1.Location = new System.Drawing.Point(34, 177);
            this.PatnName1.Margin = new System.Windows.Forms.Padding(6);
            this.PatnName1.Name = "PatnName1";
            this.PatnName1.Size = new System.Drawing.Size(173, 30);
            this.PatnName1.TabIndex = 42;
            this.PatnName1.TabStop = false;
            this.PatnName1.Text = "Patient Name";
            this.PatnName1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel2.Location = new System.Drawing.Point(34, 212);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(173, 1);
            this.panel2.TabIndex = 41;
            // 
            // Diagid
            // 
            this.Diagid.BorderColorFocused = System.Drawing.Color.Transparent;
            this.Diagid.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Diagid.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.Diagid.BorderThickness = 3;
            this.Diagid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Diagid.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Diagid.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Diagid.isPassword = false;
            this.Diagid.Location = new System.Drawing.Point(34, 97);
            this.Diagid.Margin = new System.Windows.Forms.Padding(6);
            this.Diagid.Name = "Diagid";
            this.Diagid.Size = new System.Drawing.Size(173, 30);
            this.Diagid.TabIndex = 40;
            this.Diagid.TabStop = false;
            this.Diagid.Text = "Diagnosis ID";
            this.Diagid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel3.Location = new System.Drawing.Point(34, 132);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(173, 1);
            this.panel3.TabIndex = 39;
            // 
            // Deletebtn
            // 
            this.Deletebtn.FlatAppearance.BorderSize = 2;
            this.Deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Deletebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Deletebtn.Location = new System.Drawing.Point(226, 239);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(67, 37);
            this.Deletebtn.TabIndex = 38;
            this.Deletebtn.TabStop = false;
            this.Deletebtn.Text = "Delete";
            this.Deletebtn.UseVisualStyleBackColor = true;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click);
            // 
            // Updatebtn
            // 
            this.Updatebtn.FlatAppearance.BorderSize = 2;
            this.Updatebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Updatebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Updatebtn.Location = new System.Drawing.Point(151, 239);
            this.Updatebtn.Name = "Updatebtn";
            this.Updatebtn.Size = new System.Drawing.Size(69, 37);
            this.Updatebtn.TabIndex = 37;
            this.Updatebtn.TabStop = false;
            this.Updatebtn.Text = "Update";
            this.Updatebtn.UseVisualStyleBackColor = true;
            this.Updatebtn.Click += new System.EventHandler(this.Updatebtn_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.FlatAppearance.BorderSize = 2;
            this.Addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Addbtn.Location = new System.Drawing.Point(96, 239);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(49, 37);
            this.Addbtn.TabIndex = 36;
            this.Addbtn.TabStop = false;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = true;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // homebtn
            // 
            this.homebtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.home_golden;
            this.homebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.homebtn.Location = new System.Drawing.Point(151, 291);
            this.homebtn.Name = "homebtn";
            this.homebtn.Size = new System.Drawing.Size(75, 67);
            this.homebtn.TabIndex = 0;
            this.homebtn.TabStop = false;
            this.homebtn.Click += new System.EventHandler(this.homebtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Goldenrod;
            this.label2.Location = new System.Drawing.Point(283, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(515, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "Patient Record Management System";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(459, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "Diagnosis";
            // 
            // Diagnosis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(1003, 583);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Diagnosis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Diagnosis";
            this.Load += new System.EventHandler(this.Diagnosis_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.diagsumry.ResumeLayout(false);
            this.diagsumry.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.diagshowdata)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.homebtn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox homebtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuMetroTextbox medicinebox;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.ComboBox patnidbox;
        private Bunifu.Framework.UI.BunifuMetroTextbox Diagbox;
        private System.Windows.Forms.Panel panel6;
        private Bunifu.Framework.UI.BunifuMetroTextbox Symptoms;
        private System.Windows.Forms.Panel panel5;
        private Bunifu.Framework.UI.BunifuMetroTextbox PatnName1;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuMetroTextbox Diagid;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Deletebtn;
        private System.Windows.Forms.Button Updatebtn;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Panel diagsumry;
        private System.Windows.Forms.Label medicinelbl;
        private System.Windows.Forms.Label diaglbl;
        private System.Windows.Forms.Label symptmlbl;
        private System.Windows.Forms.Label patnnamelbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2DataGridView diagshowdata;
        private System.Windows.Forms.Label clearbtn;
    }
}