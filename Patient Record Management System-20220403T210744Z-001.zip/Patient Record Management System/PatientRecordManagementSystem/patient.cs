﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PatientRecordManagementSystem
{
    public partial class patient : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-R41HJA1\SQLEXPRESS;Initial Catalog=patientrecordsystem;Integrated Security=True;Pooling=False");

        public patient()
        {
            InitializeComponent();
        }

        private void ptnthomebtn_Click(object sender, EventArgs e)
        {
            home se_form = new home();
            se_form.Show();
            this.Hide();
        }
        void showdata()
        {
            Con.Open();
            string query = "select * from PatientTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            Ptnshowdata.DataSource = ds.Tables[0];
            Con.Close();
        }
        

        private void Addbtn_Click(object sender, EventArgs e)
        {
            if ((Patnid.Text == "" || PatnName.Text == "" || PatnAddress.Text == "" || PatnAge.Text == "" || PatnPhone.Text == "" || PatnDisease.Text == ""))
                MessageBox.Show("No Empty Fill Accepted");
            {
                try
                {
                    Con.Open();
                    string query = "insert into PatientTbl values(" + Patnid.Text + ",'" + PatnName.Text + "','" + PatnAddress.Text + "','" + PatnAge.Text + "'," + PatnPhone.Text + ",'" + PatnDisease.Text + "','" + Genderbox.SelectedItem.ToString() + "','" + Bloodbox.SelectedItem.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Patient Successfully Added");
                    Con.Close();
                    showdata();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(" Empty fields");
                }

            }

        }

        private void updatebtn_Click(object sender, EventArgs e)
        {

            try
            {

                Con.Open();
                string query = "update PatientTbl set PatnName = '" + PatnName.Text + "',PatnAddress ='" + PatnAddress.Text + "',PatnAge='" + PatnAge.Text + "',PatPhone=" + PatnPhone.Text + ",Genderbox='" + Genderbox.SelectedItem.ToString() + "',Bloodbox='" + Bloodbox.SelectedItem.ToString() + "' where Patnid=" + Patnid.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Successfully updated");
                Con.Close();
                showdata();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Updated Successfully");
            }

        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (Patnid.Text == "")
                MessageBox.Show("Enter The Patient Id");
            try
            {

                
                    Con.Open();
                    string query = "delete from PatientTbl where PatnId=" + Patnid.Text + "";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Patient Successfully Deleted");
                    Con.Close();
                    showdata();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Empty fields");
            }
        }

        private void Ptnshowdata_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Patnid.Text = Ptnshowdata.SelectedRows[0].Cells[0].Value.ToString();
            PatnName.Text = Ptnshowdata.SelectedRows[0].Cells[1].Value.ToString();
            PatnAddress.Text = Ptnshowdata.SelectedRows[0].Cells[2].Value.ToString();
            PatnPhone.Text = Ptnshowdata.SelectedRows[0].Cells[3].Value.ToString();
            PatnAge.Text = Ptnshowdata.SelectedRows[0].Cells[4].Value.ToString();
            PatnDisease.Text = Ptnshowdata.SelectedRows[0].Cells[7].Value.ToString();
        }

        private void clearbtn_Click(object sender, EventArgs e)
        {
            Patnid.Text = "";
            PatnName.Text = "";
            PatnAddress.Text = "";
            PatnAge.Text = "";
            PatnPhone.Text = "";
            PatnDisease.Text = "";
            Genderbox.Text = "";
            Bloodbox.Text = "";
        }

        private void patient_Load(object sender, EventArgs e)
        {
            showdata();
        }
    }
}
