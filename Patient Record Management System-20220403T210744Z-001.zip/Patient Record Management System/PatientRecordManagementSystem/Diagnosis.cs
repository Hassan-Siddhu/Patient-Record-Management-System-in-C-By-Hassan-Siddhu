﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PatientRecordManagementSystem
{
    public partial class Diagnosis : Form
    {

        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-R41HJA1\SQLEXPRESS;Initial Catalog=patientrecordsystem;Integrated Security=True;Pooling=False");

        public Diagnosis()
        {
            InitializeComponent();
        }
        void showdatacombo()
        {
            string sql = "select * from PatientTbl";
            SqlCommand cmd = new SqlCommand(sql, Con);
            SqlDataReader rdr;
            try
            {
                Con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("Patnid", typeof(int));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                patnidbox.ValueMember = "Patnid";
                patnidbox.DataSource = dt;
                Con.Close();
            }
            catch
            {
            }
        }
        string patname;
        void fetchpatientname()
        {
            Con.Open();
            string mysql = "select * from PatientTbl where Patnid=" + patnidbox.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(mysql, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                patname = dr["PatnName"].ToString();
                PatnName1.Text = patname;
            }
            Con.Close();
        }
        void showdata()
        {
            Con.Open();
            string query = "select * from DiagnosisTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            diagshowdata.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Diagnosis_Load(object sender, EventArgs e)
        {
            showdatacombo();
            showdata();
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            if (Diagid.Text == "" || medicinebox.Text == "" || Diagbox.Text == "" || PatnName1.Text == "" || Symptoms.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
            try
            {

            
                {
                    Con.Open();
                    string query = "insert into DiagnosisTbl values(" + Diagid.Text + "," + patnidbox.SelectedValue.ToString() + ",'" + PatnName1.Text + "','" + Symptoms.Text + "','" + Diagbox.Text + "','" + medicinebox.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Diagnosis Successfully Added");
                    Con.Close();
                    showdata();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Empty fields");
            }
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                string query = "update DiagnosisTbl set Patnid = " + patnidbox.SelectedValue.ToString() + ",PatnName ='" + PatnName1.Text + "',Symptoms='" + Symptoms.Text + "',Diagnosis='" + Diagbox.Text + "',Medicines='" + medicinebox.Text + "' where DiagId=" + Diagid.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Successfully updated");
                Con.Close();
                showdata();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Updated Successfully");
            }
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (Diagid.Text == "")
                MessageBox.Show("Enter The Diagnosis Id");
            try
            {

            
                    Con.Open();
                    string query = "delete from DiagnosisTbl where DiagId=" + Diagid.Text + "";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Diagnosis Successfully Deleted");
                    Con.Close();
                    showdata();
            
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Empty fields");
            }
        }

        private void diagshowdata_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Diagid.Text = diagshowdata.SelectedRows[0].Cells[0].Value.ToString();
            patnidbox.SelectedValue = diagshowdata.SelectedRows[0].Cells[1].Value.ToString();
            PatnName1.Text = diagshowdata.SelectedRows[0].Cells[2].Value.ToString();
            Symptoms.Text = diagshowdata.SelectedRows[0].Cells[3].Value.ToString();
            Diagbox.Text = diagshowdata.SelectedRows[0].Cells[4].Value.ToString();
            medicinebox.Text = diagshowdata.SelectedRows[0].Cells[5].Value.ToString();
            patnnamelbl.Text = diagshowdata.SelectedRows[0].Cells[2].Value.ToString();
            diaglbl.Text = diagshowdata.SelectedRows[0].Cells[4].Value.ToString();
            symptmlbl.Text = diagshowdata.SelectedRows[0].Cells[3].Value.ToString();
            medicinelbl.Text = diagshowdata.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void patnidbox_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchpatientname();
        }

        private void homebtn_Click(object sender, EventArgs e)
        {
            home se_form = new home();
            se_form.Show();
            this.Hide();
        }

        private void clearbtn_Click(object sender, EventArgs e)
        {
            Diagid.Text = "";
            patnidbox.Text = "";
            PatnName1.Text = "";
            Symptoms.Text = "";
            Diagbox.Text = "";
            medicinebox.Text = "";
        }
    }
}
