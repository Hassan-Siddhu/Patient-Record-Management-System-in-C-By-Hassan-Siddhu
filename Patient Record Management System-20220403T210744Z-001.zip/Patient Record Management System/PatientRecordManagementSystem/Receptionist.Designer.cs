﻿
namespace PatientRecordManagementSystem
{
    partial class Receptionist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RecpDatashow = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Resphomebtn = new System.Windows.Forms.PictureBox();
            this.Addbtn = new System.Windows.Forms.Button();
            this.RespPass = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.RespName = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Respid = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RecpDatashow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Resphomebtn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.pngfind_com_golden_line_borders_png_825953;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.Deletebtn);
            this.panel1.Controls.Add(this.RecpDatashow);
            this.panel1.Controls.Add(this.Resphomebtn);
            this.panel1.Controls.Add(this.Addbtn);
            this.panel1.Controls.Add(this.RespPass);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.RespName);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.Respid);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(2, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(873, 523);
            this.panel1.TabIndex = 1;
            // 
            // RecpDatashow
            // 
            this.RecpDatashow.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.RecpDatashow.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.RecpDatashow.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.RecpDatashow.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.RecpDatashow.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RecpDatashow.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.RecpDatashow.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.RecpDatashow.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.RecpDatashow.ColumnHeadersHeight = 30;
            this.RecpDatashow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.RecpDatashow.DefaultCellStyle = dataGridViewCellStyle3;
            this.RecpDatashow.EnableHeadersVisualStyles = false;
            this.RecpDatashow.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.RecpDatashow.Location = new System.Drawing.Point(283, 153);
            this.RecpDatashow.Name = "RecpDatashow";
            this.RecpDatashow.RowHeadersVisible = false;
            this.RecpDatashow.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.RecpDatashow.Size = new System.Drawing.Size(516, 310);
            this.RecpDatashow.TabIndex = 20;
            this.RecpDatashow.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.RecpDatashow.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Times New Roman", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RecpDatashow.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.RecpDatashow.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.RecpDatashow.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.RecpDatashow.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.RecpDatashow.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.RecpDatashow.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.RecpDatashow.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.RecpDatashow.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RecpDatashow.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.RecpDatashow.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.RecpDatashow.ThemeStyle.HeaderStyle.Height = 30;
            this.RecpDatashow.ThemeStyle.ReadOnly = false;
            this.RecpDatashow.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.RecpDatashow.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.RecpDatashow.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RecpDatashow.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.RecpDatashow.ThemeStyle.RowsStyle.Height = 22;
            this.RecpDatashow.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.RecpDatashow.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.RecpDatashow.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.RecpDatashow_CellContentClick);
            // 
            // Resphomebtn
            // 
            this.Resphomebtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.home_golden;
            this.Resphomebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Resphomebtn.Location = new System.Drawing.Point(62, 434);
            this.Resphomebtn.Name = "Resphomebtn";
            this.Resphomebtn.Size = new System.Drawing.Size(75, 67);
            this.Resphomebtn.TabIndex = 0;
            this.Resphomebtn.TabStop = false;
            this.Resphomebtn.Click += new System.EventHandler(this.Resphomebtn_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.FlatAppearance.BorderSize = 2;
            this.Addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Addbtn.Location = new System.Drawing.Point(51, 371);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(49, 37);
            this.Addbtn.TabIndex = 18;
            this.Addbtn.TabStop = false;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = true;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // RespPass
            // 
            this.RespPass.BorderColorFocused = System.Drawing.Color.Transparent;
            this.RespPass.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.RespPass.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.RespPass.BorderThickness = 3;
            this.RespPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RespPass.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RespPass.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.RespPass.isPassword = false;
            this.RespPass.Location = new System.Drawing.Point(31, 299);
            this.RespPass.Margin = new System.Windows.Forms.Padding(6);
            this.RespPass.Name = "RespPass";
            this.RespPass.Size = new System.Drawing.Size(173, 39);
            this.RespPass.TabIndex = 17;
            this.RespPass.TabStop = false;
            this.RespPass.Text = "RespPass";
            this.RespPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel5.Location = new System.Drawing.Point(31, 343);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(173, 1);
            this.panel5.TabIndex = 16;
            // 
            // RespName
            // 
            this.RespName.BorderColorFocused = System.Drawing.Color.Transparent;
            this.RespName.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.RespName.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.RespName.BorderThickness = 3;
            this.RespName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RespName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RespName.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.RespName.isPassword = false;
            this.RespName.Location = new System.Drawing.Point(31, 229);
            this.RespName.Margin = new System.Windows.Forms.Padding(6);
            this.RespName.Name = "RespName";
            this.RespName.Size = new System.Drawing.Size(173, 39);
            this.RespName.TabIndex = 15;
            this.RespName.TabStop = false;
            this.RespName.Text = "Resp Name";
            this.RespName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel4.Location = new System.Drawing.Point(31, 273);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(173, 1);
            this.panel4.TabIndex = 14;
            // 
            // Respid
            // 
            this.Respid.BorderColorFocused = System.Drawing.Color.Transparent;
            this.Respid.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Respid.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.Respid.BorderThickness = 3;
            this.Respid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Respid.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Respid.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Respid.isPassword = false;
            this.Respid.Location = new System.Drawing.Point(31, 175);
            this.Respid.Margin = new System.Windows.Forms.Padding(6);
            this.Respid.Name = "Respid";
            this.Respid.Size = new System.Drawing.Size(173, 39);
            this.Respid.TabIndex = 11;
            this.Respid.TabStop = false;
            this.Respid.Text = "Resp ID";
            this.Respid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel2.Location = new System.Drawing.Point(31, 219);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(173, 1);
            this.panel2.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Goldenrod;
            this.label2.Location = new System.Drawing.Point(146, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(515, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "Patient Record Management System";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(298, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "Receptionist";
            // 
            // Deletebtn
            // 
            this.Deletebtn.FlatAppearance.BorderSize = 2;
            this.Deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Deletebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Deletebtn.Location = new System.Drawing.Point(119, 371);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(70, 37);
            this.Deletebtn.TabIndex = 21;
            this.Deletebtn.TabStop = false;
            this.Deletebtn.Text = "Delete";
            this.Deletebtn.UseVisualStyleBackColor = true;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click);
            // 
            // Receptionist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(878, 532);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Receptionist";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Receptionist";
            this.Load += new System.EventHandler(this.Receptionist_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RecpDatashow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Resphomebtn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox Resphomebtn;
        private System.Windows.Forms.Button Addbtn;
        private Bunifu.Framework.UI.BunifuMetroTextbox RespPass;
        private System.Windows.Forms.Panel panel5;
        private Bunifu.Framework.UI.BunifuMetroTextbox RespName;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.Framework.UI.BunifuMetroTextbox Respid;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2DataGridView RecpDatashow;
        private System.Windows.Forms.Button Deletebtn;
    }
}