﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PatientRecordManagementSystem
{
    public partial class Receptionist : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-R41HJA1\SQLEXPRESS;Initial Catalog=patientrecordsystem;Integrated Security=True;Pooling=False");

        public Receptionist()
        {
            InitializeComponent();
        }

        void showdata()
        {
            Con.Open();
            string query = "select * from ReceptionistTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            RecpDatashow.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void Resphomebtn_Click(object sender, EventArgs e)
        {
            home se_form = new home();
            se_form.Show();
            this.Hide();
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            if (Respid.Text == "" || RespName.Text == "" || RespPass.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
           
            try
                {
                    Con.Open();
                    string query = "insert into ReceptionistTbl values(" + Respid.Text + ",'" + RespName.Text + "'," + RespPass.Text + ")";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Receptionist Successfully Added");
                    Con.Close();
                    showdata();
                }
            catch (Exception ex)
            {
                MessageBox.Show(" Empty fields");
            }


        }

        private void RecpDatashow_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Respid.Text = RecpDatashow.SelectedRows[0].Cells[0].Value.ToString();
            RespName.Text = RecpDatashow.SelectedRows[0].Cells[1].Value.ToString();
            RespPass.Text = RecpDatashow.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void Receptionist_Load(object sender, EventArgs e)
        {
            showdata();
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (Respid.Text == "")
                MessageBox.Show("Enter The Receptionist id");
            try
            {
                Con.Open();
                string query = "delete from ReceptionistTbl where Respid=" + Respid.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Receptionist Successfully Deleted");
                Con.Close();
                showdata();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Empty fields");
            }
        }
    }
  
}
