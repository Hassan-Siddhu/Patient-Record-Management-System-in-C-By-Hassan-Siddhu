﻿
namespace PatientRecordManagementSystem
{
    partial class Doctor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearbtn = new System.Windows.Forms.Label();
            this.dctrbtn = new System.Windows.Forms.PictureBox();
            this.Docshowdata = new Guna.UI2.WinForms.Guna2DataGridView();
            this.dctrhomebtn = new System.Windows.Forms.PictureBox();
            this.deletebtn = new System.Windows.Forms.Button();
            this.updatebtn = new System.Windows.Forms.Button();
            this.Addbtn = new System.Windows.Forms.Button();
            this.DocPass = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.DocName = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.DocExp = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Docid = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dctrbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Docshowdata)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dctrhomebtn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.pngfind_com_golden_line_borders_png_825953;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.clearbtn);
            this.panel1.Controls.Add(this.dctrbtn);
            this.panel1.Controls.Add(this.Docshowdata);
            this.panel1.Controls.Add(this.dctrhomebtn);
            this.panel1.Controls.Add(this.deletebtn);
            this.panel1.Controls.Add(this.updatebtn);
            this.panel1.Controls.Add(this.Addbtn);
            this.panel1.Controls.Add(this.DocPass);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.DocName);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.DocExp);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.Docid);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(849, 546);
            this.panel1.TabIndex = 0;
            // 
            // clearbtn
            // 
            this.clearbtn.AutoSize = true;
            this.clearbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearbtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.clearbtn.Location = new System.Drawing.Point(173, 456);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.Size = new System.Drawing.Size(46, 19);
            this.clearbtn.TabIndex = 51;
            this.clearbtn.Text = "Clear";
            this.clearbtn.Click += new System.EventHandler(this.clearbtn_Click);
            // 
            // dctrbtn
            // 
            this.dctrbtn.BackColor = System.Drawing.Color.Transparent;
            this.dctrbtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.Doctor;
            this.dctrbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dctrbtn.Location = new System.Drawing.Point(222, 60);
            this.dctrbtn.Name = "dctrbtn";
            this.dctrbtn.Size = new System.Drawing.Size(82, 71);
            this.dctrbtn.TabIndex = 22;
            this.dctrbtn.TabStop = false;
            // 
            // Docshowdata
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.Docshowdata.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.Docshowdata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Docshowdata.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Docshowdata.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Docshowdata.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Docshowdata.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Docshowdata.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.Docshowdata.ColumnHeadersHeight = 30;
            this.Docshowdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Docshowdata.DefaultCellStyle = dataGridViewCellStyle3;
            this.Docshowdata.EnableHeadersVisualStyles = false;
            this.Docshowdata.GridColor = System.Drawing.Color.White;
            this.Docshowdata.Location = new System.Drawing.Point(256, 137);
            this.Docshowdata.Name = "Docshowdata";
            this.Docshowdata.RowHeadersVisible = false;
            this.Docshowdata.RowTemplate.Height = 30;
            this.Docshowdata.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Docshowdata.Size = new System.Drawing.Size(559, 380);
            this.Docshowdata.TabIndex = 50;
            this.Docshowdata.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Docshowdata.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Docshowdata.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Docshowdata.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Docshowdata.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Docshowdata.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Docshowdata.ThemeStyle.GridColor = System.Drawing.Color.White;
            this.Docshowdata.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Docshowdata.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.Docshowdata.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Docshowdata.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Docshowdata.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.Docshowdata.ThemeStyle.HeaderStyle.Height = 30;
            this.Docshowdata.ThemeStyle.ReadOnly = false;
            this.Docshowdata.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Docshowdata.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Docshowdata.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Docshowdata.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Docshowdata.ThemeStyle.RowsStyle.Height = 30;
            this.Docshowdata.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Docshowdata.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Docshowdata.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Docshowdata_CellContentClick);
            // 
            // dctrhomebtn
            // 
            this.dctrhomebtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.home_golden;
            this.dctrhomebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dctrhomebtn.Location = new System.Drawing.Point(77, 456);
            this.dctrhomebtn.Name = "dctrhomebtn";
            this.dctrhomebtn.Size = new System.Drawing.Size(75, 67);
            this.dctrhomebtn.TabIndex = 0;
            this.dctrhomebtn.TabStop = false;
            this.dctrhomebtn.Click += new System.EventHandler(this.dctrhomebtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.FlatAppearance.BorderSize = 2;
            this.deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deletebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletebtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.deletebtn.Location = new System.Drawing.Point(152, 398);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(67, 37);
            this.deletebtn.TabIndex = 20;
            this.deletebtn.TabStop = false;
            this.deletebtn.Text = "Delete";
            this.deletebtn.UseVisualStyleBackColor = true;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.FlatAppearance.BorderSize = 2;
            this.updatebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updatebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.updatebtn.Location = new System.Drawing.Point(77, 398);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(69, 37);
            this.updatebtn.TabIndex = 19;
            this.updatebtn.TabStop = false;
            this.updatebtn.Text = "Update";
            this.updatebtn.UseVisualStyleBackColor = true;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.FlatAppearance.BorderSize = 2;
            this.Addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Addbtn.Location = new System.Drawing.Point(22, 398);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(49, 37);
            this.Addbtn.TabIndex = 18;
            this.Addbtn.TabStop = false;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = true;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // DocPass
            // 
            this.DocPass.BorderColorFocused = System.Drawing.Color.Transparent;
            this.DocPass.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.DocPass.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.DocPass.BorderThickness = 3;
            this.DocPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DocPass.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocPass.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.DocPass.isPassword = false;
            this.DocPass.Location = new System.Drawing.Point(31, 330);
            this.DocPass.Margin = new System.Windows.Forms.Padding(6);
            this.DocPass.Name = "DocPass";
            this.DocPass.Size = new System.Drawing.Size(173, 39);
            this.DocPass.TabIndex = 17;
            this.DocPass.TabStop = false;
            this.DocPass.Text = "Password";
            this.DocPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel5.Location = new System.Drawing.Point(31, 374);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(173, 1);
            this.panel5.TabIndex = 16;
            // 
            // DocName
            // 
            this.DocName.BorderColorFocused = System.Drawing.Color.Transparent;
            this.DocName.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.DocName.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.DocName.BorderThickness = 3;
            this.DocName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DocName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocName.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.DocName.isPassword = false;
            this.DocName.Location = new System.Drawing.Point(31, 192);
            this.DocName.Margin = new System.Windows.Forms.Padding(6);
            this.DocName.Name = "DocName";
            this.DocName.Size = new System.Drawing.Size(173, 39);
            this.DocName.TabIndex = 15;
            this.DocName.TabStop = false;
            this.DocName.Text = "Doct Name";
            this.DocName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel4.Location = new System.Drawing.Point(31, 236);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(173, 1);
            this.panel4.TabIndex = 14;
            // 
            // DocExp
            // 
            this.DocExp.BorderColorFocused = System.Drawing.Color.Transparent;
            this.DocExp.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.DocExp.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.DocExp.BorderThickness = 3;
            this.DocExp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DocExp.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocExp.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.DocExp.isPassword = false;
            this.DocExp.Location = new System.Drawing.Point(31, 265);
            this.DocExp.Margin = new System.Windows.Forms.Padding(6);
            this.DocExp.Name = "DocExp";
            this.DocExp.Size = new System.Drawing.Size(184, 39);
            this.DocExp.TabIndex = 13;
            this.DocExp.TabStop = false;
            this.DocExp.Text = "Year Of Experiance";
            this.DocExp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel3.Location = new System.Drawing.Point(31, 309);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(173, 1);
            this.panel3.TabIndex = 12;
            // 
            // Docid
            // 
            this.Docid.BorderColorFocused = System.Drawing.Color.Transparent;
            this.Docid.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.Docid.BorderColorMouseHover = System.Drawing.Color.Transparent;
            this.Docid.BorderThickness = 3;
            this.Docid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Docid.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Docid.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Docid.isPassword = false;
            this.Docid.Location = new System.Drawing.Point(31, 128);
            this.Docid.Margin = new System.Windows.Forms.Padding(6);
            this.Docid.Name = "Docid";
            this.Docid.Size = new System.Drawing.Size(173, 39);
            this.Docid.TabIndex = 11;
            this.Docid.TabStop = false;
            this.Docid.Text = "Doct ID";
            this.Docid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel2.Location = new System.Drawing.Point(31, 172);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(173, 1);
            this.panel2.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Goldenrod;
            this.label2.Location = new System.Drawing.Point(71, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(515, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "Patient Record Management System";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(319, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "Doctor";
            // 
            // Doctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(852, 550);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Doctor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doctor";
            this.Load += new System.EventHandler(this.Doctor_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dctrbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Docshowdata)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dctrhomebtn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuMetroTextbox Docid;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuMetroTextbox DocPass;
        private System.Windows.Forms.Panel panel5;
        private Bunifu.Framework.UI.BunifuMetroTextbox DocName;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.Framework.UI.BunifuMetroTextbox DocExp;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox dctrhomebtn;
        private Guna.UI2.WinForms.Guna2DataGridView Docshowdata;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.PictureBox dctrbtn;
        private System.Windows.Forms.Label clearbtn;
    }
}