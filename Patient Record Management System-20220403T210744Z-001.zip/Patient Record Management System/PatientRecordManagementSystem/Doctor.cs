﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PatientRecordManagementSystem
{
    public partial class Doctor : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-R41HJA1\SQLEXPRESS;Initial Catalog=patientrecordsystem;Integrated Security=True;Pooling=False");
        public Doctor()
        {
            InitializeComponent();
        }

        void showdata()
        {
            Con.Open();
            string query = "select * from DoctorTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            Docshowdata.DataSource = ds.Tables[0]; 
            Con.Close();
        }


        private void dctrhomebtn_Click(object sender, EventArgs e)
        {
            home se_form = new home();
            se_form.Show();
            this.Hide();
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            if (Docid.Text == "" || DocName.Text == "" || DocPass.Text == "" || DocExp.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
            try
            {

                {
                    Con.Open();
                    string query = "insert into DoctorTbl values(" + Docid.Text + ",'" + DocName.Text + "'," + DocExp.Text + ",'" + DocPass.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Doctor Successfully Added");
                    Con.Close();
                    showdata();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(" Empty fields");
            }
        }

        private void Doctor_Load(object sender, EventArgs e)
        {
            showdata();
        }


        private void Docshowdata_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Docid.Text = Docshowdata.SelectedRows[0].Cells[0].Value.ToString();
            DocName.Text = Docshowdata.SelectedRows[0].Cells[1].Value.ToString();
            DocExp.Text = Docshowdata.SelectedRows[0].Cells[2].Value.ToString();
            DocPass.Text = Docshowdata.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                string query = "update DoctorTbl set DocName = '" + DocName.Text + "',DocExp ='" + DocExp.Text + "',DocPass='" + DocPass.Text + "' where Docid=" + Docid.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Successfully updated");
                Con.Close();
                showdata();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Empty fields");
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (Docid.Text == "")
                MessageBox.Show("Enter The Doctor id");
            try
            {
                Con.Open();
                string query = "delete from DoctorTbl where Docid=" + Docid.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Successfully Deleted");
                Con.Close();
                showdata();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Empty fields");
            }
        }

        private void clearbtn_Click(object sender, EventArgs e)
        {
            Docid.Text = "";
            DocName.Text = "";
            DocExp.Text = "";
            DocPass.Text = "";
        }
    }
}
