﻿
namespace PatientRecordManagementSystem
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Logoutbtn = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Receptionistbtn = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Diagnosisbtn = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.ptntbtn = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.dctrbtn = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Exitbtn = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Receptionistbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Diagnosisbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptntbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dctrbtn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.pngfind_com_golden_line_borders_png_825953;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.Exitbtn);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-4, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(766, 565);
            this.panel1.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.menu;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.bunifuCustomLabel5);
            this.panel2.Controls.Add(this.Logoutbtn);
            this.panel2.Controls.Add(this.bunifuCustomLabel4);
            this.panel2.Controls.Add(this.Receptionistbtn);
            this.panel2.Controls.Add(this.bunifuCustomLabel3);
            this.panel2.Controls.Add(this.Diagnosisbtn);
            this.panel2.Controls.Add(this.bunifuCustomLabel2);
            this.panel2.Controls.Add(this.ptntbtn);
            this.panel2.Controls.Add(this.bunifuCustomLabel1);
            this.panel2.Controls.Add(this.dctrbtn);
            this.panel2.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.panel2.Location = new System.Drawing.Point(25, 74);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(713, 464);
            this.panel2.TabIndex = 3;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(612, 410);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(68, 22);
            this.bunifuCustomLabel5.TabIndex = 9;
            this.bunifuCustomLabel5.Text = "Logout";
            // 
            // Logoutbtn
            // 
            this.Logoutbtn.BackColor = System.Drawing.Color.Transparent;
            this.Logoutbtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.logout;
            this.Logoutbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Logoutbtn.Location = new System.Drawing.Point(597, 321);
            this.Logoutbtn.Name = "Logoutbtn";
            this.Logoutbtn.Size = new System.Drawing.Size(83, 86);
            this.Logoutbtn.TabIndex = 8;
            this.Logoutbtn.TabStop = false;
            this.Logoutbtn.Click += new System.EventHandler(this.Logoutbtn_Click);
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(47, 410);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(111, 22);
            this.bunifuCustomLabel4.TabIndex = 7;
            this.bunifuCustomLabel4.Text = "Receptionist";
            // 
            // Receptionistbtn
            // 
            this.Receptionistbtn.BackColor = System.Drawing.Color.Transparent;
            this.Receptionistbtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.IMG_9665;
            this.Receptionistbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Receptionistbtn.Location = new System.Drawing.Point(60, 321);
            this.Receptionistbtn.Name = "Receptionistbtn";
            this.Receptionistbtn.Size = new System.Drawing.Size(83, 86);
            this.Receptionistbtn.TabIndex = 6;
            this.Receptionistbtn.TabStop = false;
            this.Receptionistbtn.Click += new System.EventHandler(this.Receptionistbtn_Click);
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(593, 201);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(90, 22);
            this.bunifuCustomLabel3.TabIndex = 5;
            this.bunifuCustomLabel3.Text = "Diagnosis";
            // 
            // Diagnosisbtn
            // 
            this.Diagnosisbtn.BackColor = System.Drawing.Color.Transparent;
            this.Diagnosisbtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.Diagnosis;
            this.Diagnosisbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Diagnosisbtn.Location = new System.Drawing.Point(597, 112);
            this.Diagnosisbtn.Name = "Diagnosisbtn";
            this.Diagnosisbtn.Size = new System.Drawing.Size(83, 86);
            this.Diagnosisbtn.TabIndex = 4;
            this.Diagnosisbtn.TabStop = false;
            this.Diagnosisbtn.Click += new System.EventHandler(this.Diagnosisbtn_Click);
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(56, 201);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(68, 22);
            this.bunifuCustomLabel2.TabIndex = 3;
            this.bunifuCustomLabel2.Text = "Patient";
            // 
            // ptntbtn
            // 
            this.ptntbtn.BackColor = System.Drawing.Color.Transparent;
            this.ptntbtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.Patient;
            this.ptntbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptntbtn.Location = new System.Drawing.Point(51, 112);
            this.ptntbtn.Name = "ptntbtn";
            this.ptntbtn.Size = new System.Drawing.Size(83, 86);
            this.ptntbtn.TabIndex = 2;
            this.ptntbtn.TabStop = false;
            this.ptntbtn.Click += new System.EventHandler(this.ptntbtn_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(332, 176);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(67, 22);
            this.bunifuCustomLabel1.TabIndex = 1;
            this.bunifuCustomLabel1.Text = "Doctor";
            // 
            // dctrbtn
            // 
            this.dctrbtn.BackColor = System.Drawing.Color.Transparent;
            this.dctrbtn.BackgroundImage = global::PatientRecordManagementSystem.Properties.Resources.Doctor;
            this.dctrbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dctrbtn.Location = new System.Drawing.Point(316, 65);
            this.dctrbtn.Name = "dctrbtn";
            this.dctrbtn.Size = new System.Drawing.Size(99, 108);
            this.dctrbtn.TabIndex = 0;
            this.dctrbtn.TabStop = false;
            this.dctrbtn.Click += new System.EventHandler(this.dctrbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Goldenrod;
            this.label1.Location = new System.Drawing.Point(122, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(515, 36);
            this.label1.TabIndex = 2;
            this.label1.Text = "Patient Record Management System";
            // 
            // Exitbtn
            // 
            this.Exitbtn.AutoSize = true;
            this.Exitbtn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbtn.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.Exitbtn.Location = new System.Drawing.Point(37, 34);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(46, 24);
            this.Exitbtn.TabIndex = 10;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(762, 564);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "home";
            this.Load += new System.EventHandler(this.home_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Receptionistbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Diagnosisbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptntbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dctrbtn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox dctrbtn;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private System.Windows.Forms.PictureBox ptntbtn;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private System.Windows.Forms.PictureBox Diagnosisbtn;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private System.Windows.Forms.PictureBox Logoutbtn;
        private System.Windows.Forms.PictureBox Receptionistbtn;
        private System.Windows.Forms.Label Exitbtn;
    }
}